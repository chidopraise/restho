(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [595], {
        268: function(e, s, i) {
            (window.__NEXT_P = window.__NEXT_P || []).push(["/reservation", function() {
                return i(2275)
            }])
        },
        7779: function(e, s, i) {
            "use strict";
            var c = i(5893),
                l = i(7294),
                a = i(9198),
                n = i.n(a);
            i(5828), s.Z = function() {
                let [e, s] = (0, l.useState)(!1);
                return (0, c.jsx)("div", {
                    className: "container",
                    children: (0, c.jsxs)("div", {
                        className: "reservation-1 mb-120 mt-120",
                        children: [(0, c.jsx)("div", {
                            className: "row d-flex align-items-center justify-content-center mb-40",
                            children: (0, c.jsx)("div", {
                                className: "col-lg-8",
                                children: (0, c.jsxs)("div", {
                                    className: "section-title text-center",
                                    children: [(0, c.jsxs)("span", {
                                        children: [(0, c.jsx)("img", {
                                            className: "left-vec",
                                            src: "assets/images/icon/sub-title-vec.svg",
                                            alt: "sub-title-vec"
                                        }), "Online Reserve", (0, c.jsx)("img", {
                                            className: "right-vec",
                                            src: "assets/images/icon/sub-title-vec.svg",
                                            alt: "sub-title-vec"
                                        })]
                                    }), (0, c.jsx)("h2", {
                                        children: "For Online Reservation"
                                    })]
                                })
                            })
                        }), (0, c.jsx)("div", {
                            className: "row justify-content-center",
                            children: (0, c.jsx)("div", {
                                className: "col-lg-10",
                                children: (0, c.jsx)("form", {
                                    children: (0, c.jsxs)("div", {
                                        className: "row justify-content-center",
                                        children: [(0, c.jsx)("div", {
                                            className: "col-lg-6 col-md-6 mb-25",
                                            children: (0, c.jsx)("div", {
                                                className: "form-inner",
                                                children: (0, c.jsx)("input", {
                                                    type: "text",
                                                    placeholder: "Name*"
                                                })
                                            })
                                        }), (0, c.jsx)("div", {
                                            className: "col-lg-6 col-md-6 mb-25",
                                            children: (0, c.jsx)("div", {
                                                className: "form-inner",
                                                children: (0, c.jsx)("input", {
                                                    type: "text",
                                                    placeholder: "Phone*"
                                                })
                                            })
                                        }), (0, c.jsx)("div", {
                                            className: "col-lg-6 col-md-6 mb-25",
                                            children: (0, c.jsx)("div", {
                                                className: "form-inner",
                                                children: (0, c.jsx)("input", {
                                                    type: "text",
                                                    placeholder: "People"
                                                })
                                            })
                                        }), (0, c.jsx)("div", {
                                            className: "col-lg-6 col-md-6 mb-25",
                                            children: (0, c.jsx)("div", {
                                                className: "form-inner date-icon",
                                                children: (0, c.jsx)(n(), {
                                                    selected: e,
                                                    onChange: e => s(e),
                                                    placeholderText: "Check In",
                                                    className: "claender"
                                                })
                                            })
                                        }), (0, c.jsx)("div", {
                                            className: "col-lg-6 col-md-6 mb-25",
                                            children: (0, c.jsx)("div", {
                                                className: "form-inner",
                                                children: (0, c.jsxs)("select", {
                                                    className: "time-select",
                                                    children: [(0, c.jsx)("option", {
                                                        value: "time",
                                                        children: "08 : 00 am"
                                                    }), (0, c.jsx)("option", {
                                                        children: "09 : 00 am"
                                                    }), (0, c.jsx)("option", {
                                                        value: 1,
                                                        children: "10 : 00 am"
                                                    }), (0, c.jsx)("option", {
                                                        value: 2,
                                                        children: "11 : 00 am"
                                                    }), (0, c.jsx)("option", {
                                                        value: 3,
                                                        children: "12 : 00 pm"
                                                    }), (0, c.jsx)("option", {
                                                        value: 4,
                                                        children: "01 : 00 pm"
                                                    }), (0, c.jsx)("option", {
                                                        value: 5,
                                                        children: "02 : 00 pm"
                                                    }), (0, c.jsx)("option", {
                                                        value: 6,
                                                        children: "03 : 00 pm"
                                                    }), (0, c.jsx)("option", {
                                                        value: 7,
                                                        children: "04 : 00 pm"
                                                    }), (0, c.jsx)("option", {
                                                        value: 8,
                                                        children: "05 : 00 pm"
                                                    }), (0, c.jsx)("option", {
                                                        value: 9,
                                                        children: "06 : 00 pm"
                                                    }), (0, c.jsx)("option", {
                                                        value: 10,
                                                        children: "07 : 00 pm"
                                                    }), (0, c.jsx)("option", {
                                                        value: 11,
                                                        children: "08 : 00 pm"
                                                    }), (0, c.jsx)("option", {
                                                        value: 12,
                                                        children: "09 : 00 pm"
                                                    }), (0, c.jsx)("option", {
                                                        value: 13,
                                                        children: "10 : 00 pm"
                                                    })]
                                                })
                                            })
                                        }), (0, c.jsx)("div", {
                                            className: "col-lg-6 col-md-6 sm-mb-25",
                                            children: (0, c.jsx)("div", {
                                                className: "form-inner",
                                                children: (0, c.jsx)("input", {
                                                    type: "email",
                                                    placeholder: "Email"
                                                })
                                            })
                                        }), (0, c.jsx)("div", {
                                            className: "col-lg-6 col-md-6",
                                            children: (0, c.jsx)("div", {
                                                className: "form-inner",
                                                children: (0, c.jsx)("button", {
                                                    type: "submit",
                                                    children: "Reserve Now"
                                                })
                                            })
                                        })]
                                    })
                                })
                            })
                        })]
                    })
                })
            }
        },
        2796: function(e, s, i) {
            "use strict";
            var c = i(5893),
                l = i(1664),
                a = i.n(l);
            i(7294), s.Z = function(e) {
                let {
                    pageTitle: s,
                    pageName: i
                } = e;
                return (0, c.jsxs)("div", {
                    className: "breadcrumb-section",
                    children: [(0, c.jsx)("div", {
                        className: "breadcrumb-left-vec",
                        children: (0, c.jsx)("img", {
                            src: "assets/images/icon/breadcumb-left-vec.svg",
                            alt: "breadcumb-left-vec"
                        })
                    }), (0, c.jsx)("div", {
                        className: "breadcrumb-right-vec",
                        children: (0, c.jsx)("img", {
                            src: "assets/images/icon/breadcumb-right-vec.svg",
                            alt: "breadcumb-right-vec"
                        })
                    }), (0, c.jsx)("div", {
                        className: "container",
                        children: (0, c.jsx)("div", {
                            className: "row d-flex justify-content-center align-items-center",
                            children: (0, c.jsxs)("div", {
                                className: "col-lg-12",
                                children: [(0, c.jsx)("h2", {
                                    className: "breadcrumb-title",
                                    children: s
                                }), (0, c.jsx)("nav", {
                                    "aria-label": "breadcrumb",
                                    children: (0, c.jsxs)("ol", {
                                        className: "breadcrumb d-flex",
                                        children: [(0, c.jsx)("li", {
                                            className: "breadcrumb-item",
                                            children: (0, c.jsx)(a(), {
                                                legacyBehavior: !0,
                                                href: "/",
                                                children: "Home"
                                            })
                                        }), (0, c.jsx)("li", {
                                            className: "breadcrumb-item active",
                                            "aria-current": "page",
                                            children: i
                                        })]
                                    })
                                })]
                            })
                        })
                    })]
                })
            }
        },
        1988: function(e, s, i) {
            "use strict";
            var c = i(5893),
                l = i(9008),
                a = i.n(l);
            i(7294);
            var n = i(8004),
                r = i(6282);
            s.Z = function(e) {
                let {
                    children: s
                } = e;
                return (0, c.jsxs)(c.Fragment, {
                    children: [(0, c.jsxs)(a(), {
                        children: [(0, c.jsx)("title", {
                            children: "Restho - Resturent React Template"
                        }), (0, c.jsx)("meta", {
                            name: "description",
                            content: "Generated by create next app"
                        }), (0, c.jsx)("link", {
                            rel: "icon",
                            href: "assets/images/icon/logo-icon.svg"
                        })]
                    }), (0, c.jsx)(r.Z, {}), s, (0, c.jsx)(n.Z, {})]
                })
            }
        },
        2275: function(e, s, i) {
            "use strict";
            i.r(s);
            var c = i(5893);
            i(7294);
            var l = i(7779),
                a = i(2796),
                n = i(1988);
            s.default = function() {
                return (0, c.jsxs)(n.Z, {
                    children: [(0, c.jsx)(a.Z, {
                        pageName: "Reservation",
                        pageTitle: "Reservation"
                    }), (0, c.jsxs)("div", {
                        children: [(0, c.jsx)(l.Z, {}), (0, c.jsx)("div", {
                            className: "best-offer-area1 mb-120",
                            children: (0, c.jsxs)("div", {
                                className: "container",
                                children: [(0, c.jsx)("div", {
                                    className: "row d-flex justify-content-center mb-40",
                                    children: (0, c.jsx)("div", {
                                        className: "col-lg-8",
                                        children: (0, c.jsxs)("div", {
                                            className: "section-title text-center",
                                            children: [(0, c.jsxs)("span", {
                                                children: [(0, c.jsx)("img", {
                                                    className: "left-vec",
                                                    src: "assets/images/icon/sub-title-vec.svg",
                                                    alt: "sub-title-vec"
                                                }), "Best Offer", (0, c.jsx)("img", {
                                                    className: "right-vec",
                                                    src: "assets/images/icon/sub-title-vec.svg",
                                                    alt: "sub-title-vec"
                                                })]
                                            }), (0, c.jsx)("h2", {
                                                children: "Choose Your Best Offer"
                                            })]
                                        })
                                    })
                                }), (0, c.jsxs)("div", {
                                    className: "row g-4",
                                    children: [(0, c.jsx)("div", {
                                        className: "col-lg-6 col-md-6",
                                        children: (0, c.jsxs)("div", {
                                            className: "best-offer-wrap clearfix",
                                            children: [(0, c.jsxs)("div", {
                                                className: "best-offer-img",
                                                children: [(0, c.jsx)("img", {
                                                    className: "img-fluid",
                                                    src: "assets/images/bg/best-offer-img1.png",
                                                    alt: "best-offer-img1"
                                                }), (0, c.jsx)("div", {
                                                    className: "price-tag",
                                                    children: (0, c.jsx)("span", {
                                                        children: "$55"
                                                    })
                                                })]
                                            }), (0, c.jsxs)("div", {
                                                className: "best-offer-content",
                                                children: [(0, c.jsx)("h3", {
                                                    children: "Buy One Get One Free"
                                                }), (0, c.jsxs)("p", {
                                                    children: ["If you are going to use a passage of Lorem Ipsum need.", " "]
                                                }), (0, c.jsx)("a", {
                                                    className: "primary-btn3 btn-sm",
                                                    children: "Limited Offer"
                                                }), (0, c.jsxs)("ol", {
                                                    className: "features",
                                                    children: [(0, c.jsx)("li", {
                                                        children: "Prawn with Noodls."
                                                    }), (0, c.jsx)("li", {
                                                        children: "Special Drinks."
                                                    })]
                                                })]
                                            })]
                                        })
                                    }), (0, c.jsx)("div", {
                                        className: "col-lg-6 col-md-6",
                                        children: (0, c.jsxs)("div", {
                                            className: "best-offer-wrap clearfix",
                                            children: [(0, c.jsxs)("div", {
                                                className: "best-offer-img",
                                                children: [(0, c.jsx)("img", {
                                                    className: "img-fluid",
                                                    src: "assets/images/bg/best-offer-img2.png",
                                                    alt: "best-offer-img1"
                                                }), (0, c.jsx)("div", {
                                                    className: "price-tag",
                                                    children: (0, c.jsx)("span", {
                                                        children: "$55"
                                                    })
                                                })]
                                            }), (0, c.jsxs)("div", {
                                                className: "best-offer-content",
                                                children: [(0, c.jsx)("h3", {
                                                    children: "Buy One Get One Free"
                                                }), (0, c.jsxs)("p", {
                                                    children: ["If you are going to use a passage of Lorem Ipsum need.", " "]
                                                }), (0, c.jsx)("a", {
                                                    className: "primary-btn3 btn-sm",
                                                    children: "Limited Offer"
                                                }), (0, c.jsxs)("ol", {
                                                    className: "features",
                                                    children: [(0, c.jsx)("li", {
                                                        children: "Fried Chicken."
                                                    }), (0, c.jsx)("li", {
                                                        children: "Watermelon Juice."
                                                    })]
                                                })]
                                            })]
                                        })
                                    })]
                                })]
                            })
                        })]
                    })]
                })
            }
        },
        9008: function(e, s, i) {
            e.exports = i(3121)
        },
        1163: function(e, s, i) {
            e.exports = i(880)
        }
    },
    function(e) {
        e.O(0, [664, 960, 4, 282, 774, 888, 179], function() {
            return e(e.s = 268)
        }), _N_E = e.O()
    }
]);